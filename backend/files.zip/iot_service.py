# iot_service.py — Appels API IoT + conversions
import httpx
import os
from typing import Optional

IOT_BASE_URL = os.getenv("IOT_BASE_URL", "http://guardian.pro-leaf.com:8083/wx/android/behive")

# ─── Règles de conversion ───────────────────────────────────
def convert_env(raw: dict) -> dict:
    """Convertit les valeurs brutes de l'API ENV."""
    def safe(val, divisor):
        try:
            return round(float(val) / divisor, 2) if val is not None else None
        except (TypeError, ValueError):
            return None

    return {
        "temperature": safe(raw.get("airTemperature") or raw.get("temp"),       10),
        "humidite":    safe(raw.get("airHumidity")    or raw.get("humi"),       10),
        "vpd":         safe(raw.get("vpd"),                                     100),
        "co2":         safe(raw.get("co2"),                                       1),
        "luminosite":  safe(raw.get("light")          or raw.get("lux"),          1),
    }

def convert_irr(raw: dict) -> dict:
    """Convertit les valeurs brutes de l'API IRR."""
    def safe(val, divisor):
        try:
            return round(float(val) / divisor, 2) if val is not None else None
        except (TypeError, ValueError):
            return None

    return {
        "ph":          safe(raw.get("ph"),                                      100),
        "ec":          safe(raw.get("ec"),                                      100),
        "temp_eau":    safe(raw.get("waterTemperature") or raw.get("waterTemp"), 10),
        "niveau_eau":  safe(raw.get("waterLevel")       or raw.get("level"),    100),
    }

# ─── Appels API ─────────────────────────────────────────────
async def fetch_env(device_id: int, token: str) -> Optional[dict]:
    """Appelle l'API environnement pour une serre."""
    url = f"{IOT_BASE_URL}/detailR"
    headers = {"Authorization": token}
    params  = {"deviceId": device_id}
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers=headers, params=params)
            resp.raise_for_status()
            data = resp.json()
            # L'API retourne les données dans data.data ou data directement
            raw = data.get("data") or data
            converted = convert_env(raw)
            converted["raw"] = raw
            return converted
    except Exception as e:
        print(f"[IoT ENV] Erreur device {device_id}: {e}")
        return None

async def fetch_irr(device_id: int, token: str) -> Optional[dict]:
    """Appelle l'API irrigation pour une serre."""
    url = f"{IOT_BASE_URL}/detail"
    headers = {"Authorization": token}
    params  = {"deviceId": device_id}
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers=headers, params=params)
            resp.raise_for_status()
            data = resp.json()
            raw = data.get("data") or data
            converted = convert_irr(raw)
            converted["raw"] = raw
            return converted
    except Exception as e:
        print(f"[IoT IRR] Erreur device {device_id}: {e}")
        return None

async def fetch_serre_data(serre: dict) -> dict:
    """Récupère ENV + IRR pour une serre et retourne tout fusionné."""
    env_data = await fetch_env(serre["env_device_id"], serre["env_token"])
    irr_data = await fetch_irr(serre["irr_device_id"], serre["irr_token"])

    result = {
        "serre_id":  serre["id"],
        "code":      serre["code"],
        "nom_fr":    serre["nom_fr"],
        "nom_en":    serre["nom_en"],
        "couleur":   serre["couleur"],
        "env":       env_data,
        "irr":       irr_data,
        "statut":    "ok" if (env_data or irr_data) else "erreur"
    }
    return result
